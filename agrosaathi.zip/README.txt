AgroSaathi files
index.html            -> page structure
style.css             -> design
script.js             -> behaviour (menu, language, theme, scan)
netlify/functions/scan.js -> secure server code that calls Gemini
netlify.toml          -> tells Netlify where things are
